export class User {
    constructor(
        public firstName: string,
        public email:string,
        public country?:string
    ){}
}