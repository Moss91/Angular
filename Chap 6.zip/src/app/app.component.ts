import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<user-form></user-form>',
  
})
export class AppComponent {
  title = 'AngularProject2';
}
