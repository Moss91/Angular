
import { User } from './user';
import { Component } from '@angular/core';
import { template } from '@angular/core/src/render3';

@Component({
    selector:'user-form',
    templateUrl: 'user-form.component.html'
})

export class UserFormComponent {
    countries = ['United State','Singapore','Hong Kong','Australia'];

    model = new User('','','');
    
    submitted=false;
    
    onSubmit(){
        this.submitted=true;
    }
}