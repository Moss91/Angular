import { Component, Input } from '@angular/core';

@Component({
    selector:'bs-jumbotron',
    template:`
    <div class="jumbotron">
    <h1>Hello world!</h1>
    <p>This is a simple hero unit, a simple jumbptron-style component for calling extra attention to featured content on 
    in learn more
    
    <div>
    `

})
export class JumbotronComponent{

}