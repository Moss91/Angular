import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
 <bs-jumbotron></bs-jumbotron>
  `
})
export class AppComponent {
  //isValid = false;
  onClickMe($event){
    console.log("Clicked",$event);
  }
  
}
