import { Component } from '@angular/core';

@Component({
    selector:'github',
    template:'',
})

export class NotFoundComponent{}

    