import { Component } from '@angular/core';

@Component({
    selector:'myown',
    template:'<h1>me</h1>',
})

export class MyOwnComponent{}
