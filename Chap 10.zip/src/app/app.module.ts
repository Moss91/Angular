;

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms'
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { GitHubService } from './github.service';
import { CommonModule } from '@angular/common';  
import { BrowserModule } from '@angular/platform-browser';
import { routing } from './app.routing';
import { HomeComponent } from './home.component';
import { NotFoundComponent } from './notfound.component';
import { GitHubComponent } from './github.component';
import { MyOwnComponent } from './myown.component';
import { GitHubUserComponent } from './githubuser.component';
import { LoginComponent } from './login.component';
import { AuthGuard } from './auth-guard.service';
import { LoginService } from './login.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NotFoundComponent,
    GitHubComponent,
    MyOwnComponent,
    GitHubUserComponent,
    LoginComponent
  ],
  imports: [
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserModule,
    CommonModule,
    routing,
    
  ],
  providers: [GitHubService, AuthGuard, LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
