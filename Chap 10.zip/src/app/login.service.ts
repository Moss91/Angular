import { Injectable } from '@angular/core';

@Injectable()

export class LoginService{

    isLoggedin = false;

    login(username,password){
        if(username==="jason" && password === "123")
        return this.isLoggedin = true;
        else this.isLoggedin = false;
        return this.isLoggedin;
    }

    Logout(){

        this.isLoggedin = false;
        return this.isLoggedin;
    }
}