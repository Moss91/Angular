import { Component } from '@angular/core';
import { ProductService } from './product.service';


@Component({

    selector: 'rating ',
    template:`
    <i
    class=glyphicon
    [class.glyphicon-star-empty]="rating <1"
    [class.glyphicon-star-empty]="rating >=1"
    (click)="onClick(1)"
    >
    </5>
    `,
})

export class RatingComponent{
 rating = 0;
 onClick(ratingValue){
     this.rating=ratingValue;
 }
}