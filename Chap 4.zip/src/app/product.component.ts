
import { Component } from '@angular/core';

@Component({
selector: 'product',
template: `<h2>Products</h2>
`,

})
export class ProductComponent {

}