import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <button (click)="onClickMe($event)">`
})
export class AppComponent {
  //isValid = false;
  onClickMe($event){
    console.log("Clicked",$event);
  }
  
}
