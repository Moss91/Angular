import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AngularFireModule } from 'angularfire2';
import { AngularFirestoreModule} from 'angularfire2/firestore';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersComponent } from './users.component';
import { routing } from './app.routing';
import { UserFormComponent } from './user-form.component';
import { ReactiveFormsModule } from '@angular/forms';

var config = {
    apiKey: "AIzaSyBQjPFGP8npCVwT92djoFQ0PCiPI36o1lQ",
    authDomain: "angularcrudproj2.firebaseapp.com",
    databaseURL: "https://angularcrudproj2.firebaseio.com",
    projectId: "angularcrudproj2",
    storageBucket: "angularcrudproj2.appspot.com",
    messagingSenderId: "171164002101",
    appId: "1:171164002101:web:ee6567fa6b548c2e"
}

@NgModule({
declarations: [
AppComponent,
UsersComponent,
UserFormComponent
],
imports: [
BrowserModule,
AppRoutingModule,
AngularFireModule.initializeApp(config),
AngularFirestoreModule,
routing,


ReactiveFormsModule
],
providers: [],
bootstrap: [AppComponent]
})
export class AppModule { }